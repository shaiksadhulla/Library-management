from flask import Flask,render_template,request,session
from pymongo import MongoClient
import json
from werkzeug.utils import secure_filename
import os


cluster=MongoClient('mongodb://127.0.0.1:27017')
db=cluster['digitallibrary']
users=db['users']
books = db['books']
article = db['articles']
journel = db['journels']

app=Flask(__name__)

app.secret_key='50000'
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def land():
    return render_template('home.html')

@app.route('/register',methods=['post','get'])
def register():
    username=request.form['username']
    email=request.form['email']
    password=request.form['password']
    confirmpass=request.form['cpassword']
    k={}
    k['username']=username
    k['mail']=email
    k['password']=password 
    k['donations']={}
    res=users.find_one({"username":username})
    mail=users.find_one({"email":email})
    if res:
        return render_template('register.html',status="Username already exists")
    else:
        if mail:
            return render_template('register.html',status='Email already exists')
        elif password != confirmpass:
            return render_template('register.html',status='Passwords do not match')
        elif len(password)<8:
            return render_template('register.html',status="Password must be greater than 7 characters")
        else:
            users.insert_one(k)
            return render_template('register.html',stat="Registration successful")

@app.route('/login',methods=['post','get'])
def login():
    user=request.form['username']
    password=request.form['password']
    res=users.find_one({"username":user})
    if res and res['password']==password:
        session['name']=user
        return render_template('home.html')
    else:
        return render_template('login.html',status='User does not exist or wrong password')

@app.route('/log')
def log():
    return render_template('login.html')

@app.route('/reg')
def reg():
    return render_template('register.html')

@app.route('/book')
def book():
    data = books.find()
    return render_template('book.html',books=data)

@app.route('/addBook')
def bookR():
    return render_template('booksform.html')

@app.route('/bookS',methods=['post'])
def bookS():
     # Get form data
    title = request.form['title']
    author = request.form['author']
    genre = request.form['genre']
    file = request.files['file']
    image = request.form['image']

    # Save PDF file
    filename = secure_filename(file.filename)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))

    # Insert data into MongoDB
    book_data = {
        'title': title,
        'author': author,
        'genre': genre,
        'file_path': os.path.join(UPLOAD_FOLDER, filename),
        'image':image
    }
    books.insert_one(book_data)

    return 'Book added successfully!'
    

@app.route('/journal')
def journal():
    data= journel.find()
    return render_template('journal.html',journals=data)


@app.route('/addjournal')
def journalR():
    return render_template('journalform.html')


@app.route('/journals',methods=['post'])
def journalS():
     # Get form data
    title = request.form['title']
    author = request.form['author']
    file = request.files['file']


    filename = secure_filename(file.filename)
    journal_data = {
        'title': title,
        'author': author,
        'file_path': os.path.join(UPLOAD_FOLDER, filename)
    }
    journel.insert_one(journal_data)

    return 'journal added successfully!'
    

@app.route('/article')
def articl():
    data = article.find()
    return render_template('article.html',articles=data)

@app.route('/addarticle')
def articleR():
    return render_template('articleform.html')

@app.route('/articles',methods=['post'])
def articleS():
     # Get form data
    title = request.form['title']
    author = request.form['author']
    file = request.files['file']

    
    filename = secure_filename(file.filename)
    article_data = {
        'title': title,
        'author': author,
        'file_path': os.path.join(UPLOAD_FOLDER, filename)
    }
    article.insert_one(article_data)

    return 'article added successfully!'


if __name__=='__main__':
    app.run(debug=True)